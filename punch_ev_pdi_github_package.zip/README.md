
# Punch EV PDI Inspection App

Mobile web inspection tool for Tata Punch EV delivery PDI.

## Deploy on GitHub Pages

1. Create repository `punch-ev-pdi`
2. Upload `index.html`
3. Go to Settings → Pages
4. Enable: Deploy from branch → main

Your app will be live at:

https://YOURUSERNAME.github.io/punch-ev-pdi
